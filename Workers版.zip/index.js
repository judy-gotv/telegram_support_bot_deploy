const COMMANDS = [
  { command: "start", description: "开始使用" },
  { command: "send", description: "发送消息给技术支持" },
  { command: "unban", description: "申请解禁" },
  { command: "help", description: "查看帮助" },
];

const WELCOME_TEXT = `Welcome to use APTV Support Bot~

为防止广告轰炸，发送消息时必须使用 /send 指令，例如：
/send 你好

如需申请解禁或解除禁言，请直接发送 /unban 指令`;

const HELP_TEXT = `可用命令：
/send 你的问题
/unban
/help`;

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);

    if (url.pathname === "/" && request.method === "GET") {
      return jsonResponse({ ok: true, service: "support-bot-worker" });
    }

    if (url.pathname === "/telegram/setup" && ["GET", "POST"].includes(request.method)) {
      return setupTelegram(request, env);
    }

    if (url.pathname === "/telegram/status" && ["GET", "POST"].includes(request.method)) {
      return telegramStatus(request, env);
    }

    if (url.pathname === "/telegram/webhook" && request.method === "POST") {
      return telegramWebhook(request, env, ctx);
    }

    return jsonResponse({ ok: false, error: "Not found" }, 404);
  },
};

async function telegramWebhook(request, env, ctx) {
  const config = getConfig(env);

  if (config.telegramSecretToken) {
    const token = request.headers.get("X-Telegram-Bot-Api-Secret-Token") || "";
    if (token !== config.telegramSecretToken) {
      return jsonResponse({ ok: false, error: "Unauthorized" }, 401);
    }
  }

  let update;
  try {
    update = await request.json();
  } catch {
    return jsonResponse({ ok: false, error: "Invalid JSON" }, 400);
  }

  ctx.waitUntil(
    handleUpdate(update, config).catch(async (error) => {
      try {
        await sendMessage(config, config.adminChatId, `机器人处理异常：${error.message}`);
      } catch {
        // Nothing else can be done if Telegram delivery also fails.
      }
    }),
  );

  return jsonResponse({ ok: true });
}

async function setupTelegram(request, env) {
  const config = getConfig(env);
  const url = new URL(request.url);

  if (!hasSetupAccess(request, env)) {
    return jsonResponse({ ok: false, error: "Unauthorized" }, 401);
  }

  const webhookPayload = {
    url: `${url.origin}/telegram/webhook`,
    allowed_updates: ["message", "callback_query"],
    drop_pending_updates: true,
  };

  if (config.telegramSecretToken) {
    webhookPayload.secret_token = config.telegramSecretToken;
  }

  const [commands, webhook] = await Promise.all([
    tgPost(config, "setMyCommands", { commands: COMMANDS }),
    tgPost(config, "setWebhook", webhookPayload),
  ]);

  return jsonResponse({
    ok: true,
    commands,
    webhook,
    webhook_url: webhookPayload.url,
  });
}

async function telegramStatus(request, env) {
  const config = getConfig(env);

  if (!hasSetupAccess(request, env)) {
    return jsonResponse({ ok: false, error: "Unauthorized" }, 401);
  }

  const [me, webhook] = await Promise.all([
    tgGet(config, "getMe"),
    tgGet(config, "getWebhookInfo"),
  ]);

  return jsonResponse({
    ok: true,
    bot: me.result,
    webhook: webhook.result,
  });
}

async function handleUpdate(update, config) {
  if (update && update.callback_query) {
    await handleCallbackQuery(update.callback_query, config);
    return;
  }

  const message = update && update.message;
  if (!message) return;

  const chat = message.chat || {};
  if (chat.type !== "private") return;

  await handlePrivateMessage(message, config);
}

async function handlePrivateMessage(message, config) {
  const chatId = String(message.chat.id);
  const text = String(message.text || "").trim();
  const user = message.from || {};

  if (!text) {
    await sendMessage(config, chatId, WELCOME_TEXT);
    return;
  }

  if (chatId === config.adminChatId) {
    const replyArgs = commandArgs(text, "reply");
    if (replyArgs.matched) {
      await handleAdminSend(config, chatId, replyArgs.args, "reply");
      return;
    }

    const sayArgs = commandArgs(text, "say");
    if (sayArgs.matched) {
      await handleAdminSend(config, chatId, sayArgs.args, "say");
      return;
    }

    // 管理员直接引用工单通知消息回复，无需再敲 /reply 用户ID
    const quoted = message.reply_to_message;
    if (quoted) {
      const targetId = extractUserIdFromQuoted(quoted);
      if (targetId) {
        if (!text) {
          await sendMessage(config, chatId, "回复内容不能为空，请直接输入文字后发送。");
          return;
        }
        await handleAdminSend(config, chatId, `${targetId} ${text}`, "reply");
        return;
      }
      if (text && !text.startsWith("/")) {
        await sendMessage(config, chatId, "这条引用消息里没有用户信息。请直接引用「新的工单消息」通知后输入回复内容，或使用 /reply 用户ID 回复内容。");
        return;
      }
    }
  }

  if (commandArgs(text, "start").matched) {
    await sendMessage(config, chatId, WELCOME_TEXT);
    return;
  }

  if (commandArgs(text, "help").matched) {
    await sendMessage(config, chatId, HELP_TEXT);
    return;
  }

  if (commandArgs(text, "unban").matched) {
    await sendMessage(config, chatId, "确定要申请解封吗？", {
      replyMarkup: {
        inline_keyboard: [[{ text: "✅ 确认", callback_data: "unban_confirm" }]],
      },
    });
    return;
  }

  const sendArgs = commandArgs(text, "send");
  if (sendArgs.matched) {
    if (!sendArgs.args) {
      await sendMessage(config, chatId, "格式错误，请这样发送：\n/send 你的问题");
      return;
    }

    try {
      await notifyAdmin(config, user, sendArgs.args, "工单消息");
      await sendMessage(config, chatId, "已收到，开发者看到后会尽快回复，请耐心等待。");
    } catch (error) {
      await sendMessage(config, chatId, `你的消息已收到，但通知管理员失败：${error.message}`);
    }
    return;
  }

  await sendMessage(config, chatId, WELCOME_TEXT);
}

// 根据绑定的群ID自动解封：仅当用户当前处于被封禁(kicked)状态时才调用解封
// 返回 "skipped" 表示未配置 QUNID，走原有手动流程
async function tryAutoUnban(config, user) {
  if (!config.groupId) return "skipped";

  const userId = user && user.id;
  if (!userId) return { ok: false, error: "无法获取用户ID" };

  const member = await tgGet(config, "getChatMember", {
    chat_id: config.groupId,
    user_id: userId,
  }).catch((error) => ({ error }));

  if (member.error) {
    return { ok: false, error: `查询封禁状态失败：${member.error.message}` };
  }

  const status = member.result && member.result.status;
  if (status === "kicked") {
    try {
      await tgPost(config, "unbanChatMember", {
        chat_id: config.groupId,
        user_id: userId,
      });
      return { ok: true };
    } catch (error) {
      return { ok: false, error: `解封接口失败：${error.message}` };
    }
  }

  if (status === "restricted") {
    return { ok: false, error: "账号当前为禁言状态，需管理员手动解除" };
  }

  return { ok: false, error: "账号当前没有被封禁" };
}

async function handleCallbackQuery(callbackQuery, config) {
  const data = String(callbackQuery.data || "");
  if (data !== "unban_confirm") return;

  const message = callbackQuery.message || {};
  const chat = message.chat || {};
  const user = callbackQuery.from || {};
  const chatId = String(chat.id || user.id || "");
  if (!chatId) return;

  try {
    await tgPost(config, "answerCallbackQuery", {
      callback_query_id: callbackQuery.id,
      text: "已确认",
    });
  } catch {
    // 忽略
  }

  if (message.message_id) {
    try {
      await tgPost(config, "editMessageText", {
        chat_id: chat.id,
        message_id: message.message_id,
        text: "✅ 已确认，正在为您解封...",
      });
    } catch {
      // 忽略
    }
  }

  await processUnban(config, chatId, user);
}

async function processUnban(config, chatId, user) {
  const auto = await tryAutoUnban(config, user);

  if (auto === "skipped") {
    try {
      await notifyAdmin(config, user, "/unban", "解禁申请");
      await sendMessage(config, chatId, "已收到你的解禁申请，请等待管理员处理。");
    } catch (error) {
      await sendMessage(config, chatId, `已收到你的解禁申请，但通知管理员失败：${error.message}`);
    }
    return;
  }

  if (auto.ok) {
    const groupLink = await resolveGroupLink(config);
    const doneText = groupLink
      ? `已为你自动解封，请重新入群\n点击入群：${groupLink}`
      : "已为你自动解封，请重新入群";
    await sendMessage(config, chatId, doneText);
    try {
      await notifyAdmin(config, user, "/unban（已自动解封）", "解禁申请");
    } catch {
      // 通知管理员失败不影响解封结果
    }
    return;
  }

  try {
    await notifyAdmin(config, user, `/unban（自动解封未完成：${auto.error}）`, "解禁申请");
    await sendMessage(config, chatId, `自动解封未能完成（${auto.error}），已转交管理员手动处理，请耐心等待。`);
  } catch (error) {
    await sendMessage(config, chatId, `自动解封未能完成，且通知管理员失败：${error.message}`);
  }
}

// 解析群链接：优先用 QUNAME 变量，否则用 QUNID 调 getChat 自动获取 @用户名
async function resolveGroupLink(config) {
  let name = String(config.groupUsername || "").trim().replace(/^@+/, "");
  if (!name && config.groupId) {
    try {
      const chat = await tgGet(config, "getChat", { chat_id: config.groupId });
      if (chat.result && chat.result.username) name = chat.result.username;
    } catch {
      // 获取失败则不带链接
    }
  }
  return name ? `@${name}` : "";
}

async function handleAdminSend(config, adminChatId, args, mode) {
  const parsed = parseTargetAndText(args);

  if (!parsed) {
    const usage = mode === "reply" ? "/reply 用户ID 回复内容" : "/say 用户ID 消息内容";
    await sendMessage(config, adminChatId, `用法：${usage}`);
    return;
  }

  if (!parsed.text) {
    const emptyText = mode === "reply" ? "回复内容不能为空" : "消息内容不能为空";
    await sendMessage(config, adminChatId, emptyText);
    return;
  }

  const outgoing = mode === "reply" ? `技术支持回复：\n${parsed.text}` : parsed.text;

  try {
    await sendMessage(config, parsed.targetId, outgoing);
    await sendMessage(config, adminChatId, `已发送（用户ID：${parsed.targetId}）。`);
  } catch (error) {
    await sendMessage(config, adminChatId, `发送失败：${error.message}`);
  }
}

async function notifyAdmin(config, user, text, kind = "工单消息") {
  const userId = user.id || "无";
  const firstName = user.first_name || "无";
  const usernameText = user.username ? `@${user.username}` : "无";

  const adminText = `新的${kind}
用户ID：${userId}
昵称：${firstName}
用户名：${usernameText}

内容：
${text}

回复方式（二选一）：
1. 直接引用这条消息，输入回复内容发送（推荐）
2. /reply ${userId} 你的回复内容`;

  await sendMessage(config, config.adminChatId, adminText);
}

async function sendMessage(config, chatId, text, extra = {}) {
  const payload = {
    chat_id: chatId,
    text,
  };

  if (extra.replyToMessageId) {
    payload.reply_to_message_id = extra.replyToMessageId;
  }

  if (extra.replyMarkup) {
    payload.reply_markup = extra.replyMarkup;
  }

  return tgPost(config, "sendMessage", payload);
}

async function tgPost(config, method, payload = {}) {
  const response = await fetch(`${config.baseUrl}/${method}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(payload),
  });

  const bodyText = await response.text();
  let body;

  try {
    body = bodyText ? JSON.parse(bodyText) : {};
  } catch {
    body = { ok: false, description: bodyText };
  }

  if (!response.ok || body.ok === false) {
    const description = body.description || response.statusText || "Telegram API error";
    throw new Error(`${method} failed: ${description}`);
  }

  return body;
}

async function tgGet(config, method, params = {}) {
  const url = new URL(`${config.baseUrl}/${method}`);
  for (const [key, value] of Object.entries(params)) {
    url.searchParams.set(key, value);
  }

  const response = await fetch(url);
  const bodyText = await response.text();
  let body;

  try {
    body = bodyText ? JSON.parse(bodyText) : {};
  } catch {
    body = { ok: false, description: bodyText };
  }

  if (!response.ok || body.ok === false) {
    const description = body.description || response.statusText || "Telegram API error";
    throw new Error(`${method} failed: ${description}`);
  }

  return body;
}

function hasSetupAccess(request, env) {
  const url = new URL(request.url);
  const setupSecret = String(env.SETUP_SECRET || "").trim();
  const providedSecret = url.searchParams.get("secret") || request.headers.get("X-Setup-Secret") || "";

  return Boolean(setupSecret && providedSecret === setupSecret);
}

function commandArgs(text, command) {
  const pattern = new RegExp(`^/${command}(?:@[A-Za-z0-9_]+)?(?:\\s+([\\s\\S]*))?$`);
  const match = text.match(pattern);

  return {
    matched: Boolean(match),
    args: match && match[1] ? match[1].trim() : "",
  };
}

// 从被引用的工单通知消息中解析出目标用户ID（无状态，无需额外存储）
function extractUserIdFromQuoted(quoted) {
  if (!quoted || !quoted.from || !quoted.from.is_bot) return null;
  const match = String(quoted.text || "").match(/用户ID：(\d+)/);
  return match ? match[1] : null;
}

function parseTargetAndText(args) {
  const match = String(args || "").trim().match(/^(\S+)\s+([\s\S]+)$/);
  if (!match) return null;

  return {
    targetId: match[1],
    text: match[2].trim(),
  };
}

function getConfig(env) {
  const botToken = String(env.BOT_TOKEN || "").trim();
  const adminChatId = String(env.ADMIN_CHAT_ID || "").trim();
  const telegramSecretToken = String(env.TELEGRAM_SECRET_TOKEN || "").trim();
  // 绑定的群组ID（自动解封用，例如 -1002176362246；未设置则 /unban 走手动流程）
  const groupId = String(env.QUNID || "").trim();
  // 绑定的群 @用户名（例如 AptvPlayer，可不带 @；不填则用 QUNID 自动获取）
  const groupUsername = String(env.QUNAME || "").trim();

  if (!botToken) {
    throw new Error("BOT_TOKEN 未设置");
  }

  if (!adminChatId || adminChatId === "0") {
    throw new Error("ADMIN_CHAT_ID 未设置");
  }

  return {
    botToken,
    adminChatId,
    telegramSecretToken,
    groupId,
    groupUsername,
    baseUrl: `https://api.telegram.org/bot${botToken}`,
  };
}

function jsonResponse(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
    },
  });
}