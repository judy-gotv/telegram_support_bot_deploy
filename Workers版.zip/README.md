# TG Support Bot for Cloudflare Workers

这个版本已经把原来的 FastAPI webhook 机器人迁到 Cloudflare Workers。Worker 入口是 `src/index.js`，生产部署用 `wrangler.jsonc`。

## 本地运行

```powershell
npm install
Copy-Item .dev.vars.example .dev.vars
```

编辑 `.dev.vars`，填入：

```ini
BOT_TOKEN=你的 Telegram Bot Token
ADMIN_CHAT_ID=你的 Telegram 私聊 chat_id
SETUP_SECRET=一个随机密码
TELEGRAM_SECRET_TOKEN=另一个随机密码
```

然后运行：

```powershell
npm run dev
```

## 部署到 Cloudflare Workers

先把 `wrangler.jsonc` 里的 `ADMIN_CHAT_ID` 改成你的 Telegram 私聊 chat_id。

```powershell
npm install
npx wrangler login
npx wrangler secret put BOT_TOKEN
npx wrangler secret put SETUP_SECRET
npx wrangler secret put TELEGRAM_SECRET_TOKEN
npm run deploy
```

部署完成后，访问下面这个地址初始化 Telegram webhook 和 bot 命令：

```text
https://你的-worker域名/telegram/setup?secret=你的SETUP_SECRET
```

看到 `{"ok":true,...}` 后，机器人就会通过 `/telegram/webhook` 接收 Telegram 消息。

更详细的图文式步骤见 `部署教程.md`。

## 可用命令

普通用户：

```text
/start
/help
/send 你的问题
/unban
```

管理员：

```text
/reply 用户ID 回复内容
/say 用户ID 消息内容
```

## 说明

`app.py` 和 `support_bot.py` 是原 Python 版本的参考文件，Cloudflare Workers 部署不会使用它们。
